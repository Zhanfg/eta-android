package dev.gboard.enhancer;

import android.app.AndroidAppHelper;
import android.content.Context;
import java.lang.reflect.Field;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class GboardHook implements IXposedHookLoadPackage {
    private static final String TARGET = "com.google.android.inputmethod.latin";

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam p) {
        if (!TARGET.equals(p.packageName)) return;
        if (install1831FastPath(p)) return;
        XposedBridge.log("GboardEnhancer: 18.3.1 fast-path not found; DexKit fallback not active in v0.1-dev");
    }

    // Verified against Gboard 18.3.1.977415014:
    // Lacps;->g()Ljava/lang/Object; with flag name in Lacps;->a:Ljava/lang/String;
    private boolean install1831FastPath(XC_LoadPackage.LoadPackageParam p) {
        try {
            Class<?> cls = XposedHelpers.findClass("acps", p.classLoader);
            Field nameField = cls.getDeclaredField("a");
            nameField.setAccessible(true);
            XposedHelpers.findAndHookMethod(cls, "g", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    Object original = param.getResult();
                    Object receiver = param.thisObject;
                    if (receiver == null || original == null) return;
                    String flagName = (String) nameField.get(receiver);
                    Context c = AndroidAppHelper.currentApplication();
                    if (c == null) return;
                    Object replacement = FlagOverrideEngine.apply(flagName, original, ConfigClient.get(c));
                    if (replacement != original && !replacement.equals(original)) param.setResult(replacement);
                }
            });
            XposedBridge.log("GboardEnhancer: installed acps#g flag hook for Gboard 18.3.1");
            return true;
        } catch (Throwable t) {
            XposedBridge.log("GboardEnhancer: fast-path failed: " + t);
            return false;
        }
    }
}
