package dev.gboard.enhancer;

public final class ModelCatalog {
    // Observed directly in Gboard 18.3.1.977415014 strings.
    public static final String HANDWRITING_MANIFEST =
        "https://dl.google.com/handwriting/models/handwriting_release.superpack_manifest.20260206.json";
    public static final String SPEECH_FULL_MANIFEST =
        "https://dl.google.com/android/voice/gboard/en_us/ondevice_recognizer/superpacks-manifest-20191115.json";
    public static final String SPEECH_SMALL_MANIFEST =
        "https://dl.google.com/android/voice/gboard/terse/superpacks-manifest-20210519.json";
    public static final String CHINESE_DICTIONARY_METADATA =
        "https://www.gstatic.com/android/keyboard/dictionarypack/2026062420/metadata.json";

    private ModelCatalog() {}
}
