package dev.gboard.enhancer;

public final class Config {
    public final boolean writingTools;
    public final boolean regionBypass;
    public final boolean modelUnlock;
    public final boolean experimental;
    public final String forcedCountry;

    public Config(boolean writingTools, boolean regionBypass, boolean modelUnlock,
                  boolean experimental, String forcedCountry) {
        this.writingTools = writingTools;
        this.regionBypass = regionBypass;
        this.modelUnlock = modelUnlock;
        this.experimental = experimental;
        this.forcedCountry = forcedCountry == null ? "US" : forcedCountry;
    }
}
