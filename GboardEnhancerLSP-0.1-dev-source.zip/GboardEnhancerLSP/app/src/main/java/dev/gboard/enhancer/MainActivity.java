package dev.gboard.enhancer;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.*;

public final class MainActivity extends Activity {
    private SharedPreferences prefs;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(ConfigProvider.PREFS, 0);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 32, 32, 32);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("Gboard Enhancer 0.1-dev\nTarget: Gboard 18.3.1.977415014");
        title.setTextSize(20);
        root.addView(title);

        root.addView(toggle("AI Writing Tools / My Style / Smart Reply", "writingTools", true));
        root.addView(toggle("绕过地区/语言限制（保守模式）", "regionBypass", true));
        root.addView(toggle("解锁手写/离线语音模型下载", "modelUnlock", true));
        root.addView(toggle("实验性 Flag（Emojify / Agentic Dictation / 全局国家过滤）", "experimental", false));

        EditText country = new EditText(this);
        country.setHint("模拟国家代码，例如 US");
        country.setText(prefs.getString("forcedCountry", "US"));
        country.setOnFocusChangeListener((v, hasFocus) -> { if (!hasFocus) prefs.edit().putString("forcedCountry", country.getText().toString().trim()).apply(); });
        root.addView(country);

        addDownload(root, "下载手写模型清单（诊断）", ModelCatalog.HANDWRITING_MANIFEST, "handwriting_manifest.json");
        addDownload(root, "下载中文词库 metadata（诊断）", ModelCatalog.CHINESE_DICTIONARY_METADATA, "zh_dictionary_metadata.json");
        addDownload(root, "下载离线语音模型清单（诊断）", ModelCatalog.SPEECH_FULL_MANIFEST, "speech_manifest.json");

        TextView note = new TextView(this);
        note.setText("说明：v0.1 已让 Gboard 自己的 flag getter 指向真实模型 manifest，并解除自动下载/计费网络限制。上面的“下载”按钮目前用于验证端点，不会把文件硬塞进 Gboard 私有目录。下一阶段会 Hook Superpacks/MDD 刷新入口，实现按钮→Gboard 原生同步。修改开关后建议强制停止并重新启动 Gboard。");
        root.addView(note);
    }

    private Switch toggle(String text, String key, boolean def) {
        Switch s = new Switch(this);
        s.setText(text);
        s.setChecked(prefs.getBoolean(key, def));
        s.setOnCheckedChangeListener((b, checked) -> prefs.edit().putBoolean(key, checked).apply());
        return s;
    }

    private void addDownload(LinearLayout root, String label, String url, String file) {
        Button b = new Button(this);
        b.setText(label);
        b.setOnClickListener(v -> {
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, file);
            ((DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(req);
            Toast.makeText(this, "已交给系统下载器", Toast.LENGTH_SHORT).show();
        });
        root.addView(b);
    }
}
