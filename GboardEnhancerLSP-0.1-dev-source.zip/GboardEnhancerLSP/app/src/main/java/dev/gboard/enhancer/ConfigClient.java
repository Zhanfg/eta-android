package dev.gboard.enhancer;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

public final class ConfigClient {
    private static final Uri URI = Uri.parse("content://dev.gboard.enhancer.config");
    private static volatile Config cached = new Config(true, true, true, false, "US");
    private static volatile long lastRead;

    public static Config get(Context c) {
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastRead < 5000) return cached;
        lastRead = now;
        try {
            Bundle b = c.getContentResolver().call(URI, "snapshot", null, null);
            if (b != null) cached = new Config(
                b.getBoolean("writingTools", true),
                b.getBoolean("regionBypass", true),
                b.getBoolean("modelUnlock", true),
                b.getBoolean("experimental", false),
                b.getString("forcedCountry", "US")
            );
        } catch (Throwable ignored) {}
        return cached;
    }
}
