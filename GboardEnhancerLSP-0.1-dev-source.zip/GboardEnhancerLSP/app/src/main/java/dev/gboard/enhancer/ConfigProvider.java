package dev.gboard.enhancer;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

public final class ConfigProvider extends ContentProvider {
    static final String PREFS = "config";

    @Override public boolean onCreate() { return true; }

    @Override public Bundle call(String method, String arg, Bundle extras) {
        if (!"snapshot".equals(method)) return Bundle.EMPTY;
        SharedPreferences p = getContext().getSharedPreferences(PREFS, 0);
        Bundle b = new Bundle();
        b.putBoolean("writingTools", p.getBoolean("writingTools", true));
        b.putBoolean("regionBypass", p.getBoolean("regionBypass", true));
        b.putBoolean("modelUnlock", p.getBoolean("modelUnlock", true));
        b.putBoolean("experimental", p.getBoolean("experimental", false));
        b.putString("forcedCountry", p.getString("forcedCountry", "US"));
        return b;
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) { return null; }
    @Override public String getType(Uri uri) { return null; }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
}
