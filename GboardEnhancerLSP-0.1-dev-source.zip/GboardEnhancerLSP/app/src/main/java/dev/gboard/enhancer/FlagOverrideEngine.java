package dev.gboard.enhancer;

import java.util.Set;

public final class FlagOverrideEngine {
    private static final Set<String> WRITING_TRUE = Set.of(
        "writing_helper", "config_proofread", "writing_tools",
        "writing_helper_on_selected_text",
        "writing_helper_enable_text_stylization_internal",
        "enable_writing_tools_cooperative_mode",
        "enable_writing_tools_for_minors",
        "enable_writing_tools_voice_commands",
        "enable_nga_lab_modeless_smartedit",
        "enable_writing_tools_suggest_style",
        "enable_writing_tools_my_style",
        "enable_writing_tools_my_style_plus",
        "enable_writing_tools_my_style_plus_without_screen_context",
        "writing_tools_enable_smart_reply",
        "writing_tools_v2_enable_p13n",
        "writing_tools_v2_enable_suggested_instructions",
        "writing_tools_v2_enable_suggested_instructions_toast",
        "writing_tools_enable_streaming_ui",
        "enable_writing_tools_replace_button",
        "enable_writing_tools_thumb_up_and_down",
        "writing_tools_context_enable_inline"
    );

    private static final Set<String> MODEL_TRUE = Set.of(
        "enable_ondevice_recognizer",
        "force_speech_language_pack_updates",
        "allow_metered_small_speech_pack_downloads",
        "enable_handwriting_promo"
    );

    private static final Set<String> EXPERIMENTAL_TRUE = Set.of(
        "enable_emojify_model",
        "enable_agentic_dictation",
        "nga_enable_mic_button_when_dictation_eligible",
        "mdd_superpack_enabled",
        "use_mdd_for_superpack"
    );

    public static Object apply(String name, Object original, Config cfg) {
        if (name == null || original == null) return original;

        if (cfg.writingTools) {
            if (WRITING_TRUE.contains(name) && original instanceof Boolean) return Boolean.TRUE;
            if ((name.equals("writing_helper_supported_language_tags") ||
                 name.equals("llm_pc_supported_language_tags")) && original instanceof String) return "*";
            if (name.equals("writing_tools_v2_backend_type") && original instanceof Long) return 1L;
            if (name.equals("writing_tools_enable_hybrid") && original instanceof Boolean) return Boolean.FALSE;
        }

        if (cfg.regionBypass) {
            if (name.equals("device_country_for_testing") && original instanceof String) return cfg.forcedCountry;
            if (name.equals("agentic_dictation_excluded_language_tags") && original instanceof String) return "";
            // Country filtering is risky globally; only disable it in experimental mode.
            if (cfg.experimental && name.equals("use_jni_results_to_filter_country_flags") && original instanceof Boolean) return Boolean.FALSE;
        }

        if (cfg.modelUnlock) {
            if (MODEL_TRUE.contains(name) && original instanceof Boolean) return Boolean.TRUE;
            if (name.equals("disable_ondevice_auto_download") && original instanceof Boolean) return Boolean.FALSE;
            if (name.equals("handwriting_superpacks_manifest_url_v2") && original instanceof String)
                return ModelCatalog.HANDWRITING_MANIFEST;
            if (name.equals("speech_superpacks_manifest_url") && original instanceof String)
                return ModelCatalog.SPEECH_FULL_MANIFEST;
            if (name.equals("speech_superpacks_small_lps_manifest_url") && original instanceof String)
                return ModelCatalog.SPEECH_SMALL_MANIFEST;
        }

        if (cfg.experimental && EXPERIMENTAL_TRUE.contains(name) && original instanceof Boolean) return Boolean.TRUE;
        return original;
    }

    private FlagOverrideEngine() {}
}
