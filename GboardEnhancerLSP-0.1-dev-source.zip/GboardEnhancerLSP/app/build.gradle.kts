plugins { id("com.android.application") }

android {
    namespace = "dev.gboard.enhancer"
    compileSdk = 36
    defaultConfig {
        applicationId = "dev.gboard.enhancer"
        minSdk = 31
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0-dev"
    }
}

dependencies {
    compileOnly("de.robv.android.xposed:api:82")
    implementation("org.luckypray:dexkit:2.2.0")
}
