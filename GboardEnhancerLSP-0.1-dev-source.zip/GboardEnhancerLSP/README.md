# Gboard Enhancer LSP

Development LSPosed module targeting Gboard `18.3.1.977415014`.

## v0.1-dev implemented

- Runtime hook of the verified 18.3.1 Gboard flag getter (`acps#g`, flag name in `acps.a`).
- Writing Tools / Proofread / My Style / Smart Reply / streaming UI flag overrides.
- Conservative region/language bypass: test-country override, language allowlists, Agentic Dictation exclusion clearing.
- Model-download unlocks: on-device recognizer, auto-download, metered small speech packs, handwriting manifest, speech manifests.
- Small module UI with switches and diagnostic manifest downloads.
- Cross-process config through a ContentProvider with a 5 s cache in the Gboard process.

## Not yet claimed as finished

- DexKit fallback for future Gboard builds is scaffolded conceptually but v0.1 uses the exact 18.3.1 binding.
- The model buttons currently validate/download manifests to the module's own external-files directory. They do **not** copy model blobs into Gboard private storage.
- Direct one-tap `button -> invoke Gboard Superpacks/MDD sync -> installed` needs the 18.3.1 Superpacks/MDD refresh method to be resolved and hooked. The safer target is Gboard's own downloader, not manual writes under `/data/data`.

## Build

Open in Android Studio with JDK 17+, Android SDK 36. Build `app:assembleDebug`. Install the APK, enable its LSPosed scope only for `com.google.android.inputmethod.latin`, then force-stop/restart Gboard.
