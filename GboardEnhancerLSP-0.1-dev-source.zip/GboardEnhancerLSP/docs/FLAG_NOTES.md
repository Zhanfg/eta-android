# Gboard 18.3.1.977415014 notes

Verified flag getter from PixelBoard's 18.3.1 binding:
- class: `acps`
- method: `g()` -> `Object`
- flag name field: `acps.a:String`

Observed model/download flags in the supplied APK:
- `handwriting_superpacks_manifest_url_v2`
- `handwriting_superpacks_manifest_version_v2`
- `speech_superpacks_manifest_url`
- `speech_superpacks_small_lps_manifest_url`
- `force_speech_language_pack_updates`
- `allow_metered_small_speech_pack_downloads`
- `disable_ondevice_auto_download`
- `mdd_superpack_enabled`
- `use_mdd_for_superpack`

Observed region/language related candidates:
- `device_country_for_testing`
- `use_jni_results_to_filter_country_flags`
- `writing_tools_v2_enable_mcc_country`
- `writing_helper_supported_language_tags`
- `llm_pc_supported_language_tags`
- `agentic_dictation_excluded_language_tags`

`writing_tools_v2_enable_mcc_country` is intentionally not forced in v0.1 because its semantics may be prompt/personalization-related rather than a pure eligibility gate.
